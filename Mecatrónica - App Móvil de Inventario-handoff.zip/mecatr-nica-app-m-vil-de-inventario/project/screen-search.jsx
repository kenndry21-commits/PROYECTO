// Pantalla 5: Búsqueda activa con resultados y teclado
const T = window.MECA_THEME;

const SearchResultRow = ({ p, query }) => {
  const c = window.stockColor(p.stock);
  const bg = window.stockContainer(p.stock);
  // Resaltar coincidencia
  const idx = p.name.toLowerCase().indexOf(query.toLowerCase());
  const before = idx >= 0 ? p.name.slice(0, idx) : p.name;
  const match = idx >= 0 ? p.name.slice(idx, idx + query.length) : '';
  const after = idx >= 0 ? p.name.slice(idx + query.length) : '';

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px', background: T.surface }}>
      <div style={{
        width: 40, height: 40, borderRadius: 10, background: T.surfaceContainer,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name="inventory" size={20} color={T.primary} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 600, color: T.onSurface, lineHeight: '20px',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {before}<span style={{ background: '#FEF08A', color: T.onSurface, padding: '0 2px', borderRadius: 3 }}>{match}</span>{after}
        </div>
        <div style={{ fontSize: 13, color: T.onSurfaceMuted, marginTop: 2,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.description}</div>
      </div>
      <div style={{
        padding: '4px 10px', borderRadius: 8, background: bg, color: c,
        fontSize: 12, fontWeight: 700, flexShrink: 0,
      }}>{p.stock}</div>
    </div>
  );
};

const SearchScreen = () => {
  const query = 'aceite';
  const results = window.MECA_PRODUCTS.filter(p =>
    p.name.toLowerCase().includes(query) || p.description.toLowerCase().includes(query)
  );
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: T.surfaceDim, fontFamily: 'Roboto, system-ui, sans-serif' }}>
      <StatusBar />

      {/* Search bar M3 */}
      <div style={{
        height: 64, padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 4,
        background: T.surface, borderBottom: `1px solid ${T.outlineVariant}`, flexShrink: 0,
      }}>
        <IconButton icon="back" color={T.onSurface} />
        <div style={{
          flex: 1, height: 48, borderRadius: 24, background: T.surfaceContainer,
          display: 'flex', alignItems: 'center', gap: 12, padding: '0 18px',
        }}>
          <span style={{ fontSize: 16, color: T.onSurface, flex: 1, fontWeight: 500 }}>
            {query}<span style={{ display: 'inline-block', width: 1.5, height: 18, background: T.primary, marginLeft: 2, verticalAlign: 'middle', animation: 'blink 1s infinite' }}/>
          </span>
          <Icon name="close" size={20} color={T.onSurfaceMuted} />
          <Icon name="mic" size={20} color={T.primary} />
        </div>
      </div>

      {/* Filter chips */}
      <div style={{
        background: T.surface, padding: '4px 16px 12px', display: 'flex', gap: 8,
        overflowX: 'auto', borderBottom: `1px solid ${T.outlineVariant}`, flexShrink: 0,
      }}>
        <Chip selected leading={<Icon name="check" size={14} color={T.primary} />}>Todos</Chip>
        <Chip>Lubricantes</Chip>
        <Chip>Filtros</Chip>
        <Chip>Frenos</Chip>
        <Chip>Motor</Chip>
      </div>

      <div style={{ flex: 1, overflow: 'auto' }}>
        {/* Sugerencias recientes header */}
        <div style={{ padding: '12px 16px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: T.onSurfaceMuted, letterSpacing: 0.5 }}>
            {results.length} RESULTADOS
          </div>
          <div style={{ fontSize: 13, color: T.primary, fontWeight: 600 }}>Limpiar búsqueda</div>
        </div>

        <div style={{ background: T.surface }}>
          {results.map((p, i) => (
            <React.Fragment key={p.id}>
              <SearchResultRow p={p} query={query} />
              {i < results.length - 1 && <div style={{ height: 1, background: T.outlineVariant, marginLeft: 70 }} />}
            </React.Fragment>
          ))}
        </div>

        {/* Búsquedas recientes */}
        <div style={{ padding: '20px 16px 8px' }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: T.onSurfaceMuted, letterSpacing: 0.5, marginBottom: 8 }}>BÚSQUEDAS RECIENTES</div>
        </div>
        <div style={{ background: T.surface }}>
          {['filtro mann', 'pastillas freno', 'bujías ngk', 'refrigerante'].map((q, i, arr) => (
            <div key={q} style={{
              display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px',
              borderBottom: i < arr.length - 1 ? `1px solid ${T.outlineVariant}` : 'none',
            }}>
              <Icon name="history" size={20} color={T.onSurfaceMuted} />
              <div style={{ flex: 1, fontSize: 15, color: T.onSurface }}>{q}</div>
              <Icon name="close" size={18} color={T.onSurfaceMuted} />
            </div>
          ))}
        </div>
      </div>

      {/* Mini teclado simulado */}
      <SimpleKeyboard />
      <NavBar />
    </div>
  );
};

const SimpleKeyboard = () => {
  const rows = [
    'qwertyuiop',
    'asdfghjkl',
    '⇧zxcvbnm⌫',
  ];
  const keyStyle = (l) => ({
    flex: l === '⇧' || l === '⌫' ? 1.4 : 1,
    height: 42, borderRadius: 6, background: '#fff',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: 18, color: T.onSurface, fontFamily: 'Roboto, system-ui, sans-serif',
    boxShadow: '0 1px 0 rgba(0,0,0,0.1)',
  });
  return (
    <div style={{ background: '#D1D5DB', padding: '8px 4px', flexShrink: 0 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {rows.map((row, i) => (
          <div key={i} style={{ display: 'flex', gap: 4, padding: i === 1 ? '0 16px' : '0 4px' }}>
            {[...row].map((l, j) => (
              <div key={j} style={keyStyle(l)}>{l === '⇧' || l === '⌫' ? <span style={{ fontSize: 16, color: T.onSurfaceMuted }}>{l}</span> : l}</div>
            ))}
          </div>
        ))}
        <div style={{ display: 'flex', gap: 4, padding: '0 4px' }}>
          <div style={{ ...keyStyle('?'), flex: 1.3, fontSize: 13 }}>?123</div>
          <div style={{ ...keyStyle(','), flex: 1, fontSize: 14 }}>,</div>
          <div style={{ ...keyStyle(' '), flex: 5 }}></div>
          <div style={{ ...keyStyle('.'), flex: 1, fontSize: 14 }}>.</div>
          <div style={{ ...keyStyle('↵'), flex: 1.3, background: T.primary, color: '#fff', fontSize: 16 }}>↵</div>
        </div>
      </div>
    </div>
  );
};

window.SearchScreen = SearchScreen;
