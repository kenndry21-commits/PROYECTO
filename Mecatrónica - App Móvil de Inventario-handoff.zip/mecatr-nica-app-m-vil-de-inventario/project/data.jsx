// Datos compartidos para la app Mecatrónica
// Productos típicos de un taller automotriz dominicano

const MECA_THEME = {
  // Azul corporativo oscuro (basado en blue-700/800 del web)
  primary: '#1E3A8A',
  primaryDark: '#172554',
  primaryContainer: '#DBEAFE',
  onPrimary: '#FFFFFF',
  onPrimaryContainer: '#1E3A8A',

  surface: '#FFFFFF',
  surfaceDim: '#F8FAFC',
  surfaceContainer: '#F1F5F9',
  surfaceContainerHigh: '#E2E8F0',
  outline: '#CBD5E1',
  outlineVariant: '#E2E8F0',

  onSurface: '#0F172A',
  onSurfaceVariant: '#475569',
  onSurfaceMuted: '#64748B',

  // Stock indicators (Material 3 semantic)
  stockOk: '#16A34A',
  stockOkContainer: '#DCFCE7',
  stockLow: '#CA8A04',
  stockLowContainer: '#FEF9C3',
  stockOut: '#DC2626',
  stockOutContainer: '#FEE2E2',

  error: '#DC2626',
  errorContainer: '#FEE2E2',
};

const MECA_PRODUCTS = [
  { id: '1', name: 'Aceite Mobil 1 5W-30', description: 'Sintético full', price: 1850, stock: 12, unit: 'galon', category: 'Lubricantes' },
  { id: '2', name: 'Filtro de aceite Mann W67/2', description: 'Toyota Corolla 2010-2020', price: 350, stock: 4, unit: 'unidad', category: 'Filtros' },
  { id: '3', name: 'Pastillas de freno Akebono', description: 'Delanteras Honda Civic', price: 2200, stock: 0, unit: 'caja', category: 'Frenos' },
  { id: '4', name: 'Refrigerante Prestone', description: 'Verde universal concentrado', price: 480, stock: 18, unit: 'galon', category: 'Fluidos' },
  { id: '5', name: 'Bujías NGK Iridium', description: 'IZFR6K-11 (4 unidades)', price: 1650, stock: 7, unit: 'caja', category: 'Encendido' },
  { id: '6', name: 'Aceite ATF Dexron VI', description: 'Transmisión automática', price: 720, stock: 3, unit: 'litro', category: 'Lubricantes' },
  { id: '7', name: 'Filtro de aire K&N', description: 'Reusable lavable', price: 3400, stock: 2, unit: 'unidad', category: 'Filtros' },
  { id: '8', name: 'Grasa para rodamientos', description: 'Mobilgrease XHP 222', price: 95, stock: 24, unit: 'kg', category: 'Lubricantes' },
  { id: '9', name: 'Líquido de frenos DOT 4', description: 'Bosch alta temperatura', price: 380, stock: 0, unit: 'litro', category: 'Frenos' },
  { id: '10', name: 'Correa de tiempo Gates', description: 'T295 Toyota 2.4L', price: 1950, stock: 5, unit: 'unidad', category: 'Motor' },
];

const UNIT_LABELS = {
  unidad: 'Unidad',
  galon: 'Galón',
  litro: 'Litro',
  kg: 'Kilogramo',
  caja: 'Caja',
};

// Helper: formato RD$
const fmtRD = (n) => `RD$${Number(n).toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// Helper: nivel de stock
const stockLevel = (s) => s <= 0 ? 'out' : s <= 5 ? 'low' : 'ok';
const stockColor = (s) => {
  const l = stockLevel(s);
  return l === 'out' ? MECA_THEME.stockOut : l === 'low' ? MECA_THEME.stockLow : MECA_THEME.stockOk;
};
const stockContainer = (s) => {
  const l = stockLevel(s);
  return l === 'out' ? MECA_THEME.stockOutContainer : l === 'low' ? MECA_THEME.stockLowContainer : MECA_THEME.stockOkContainer;
};
const stockLabel = (s) => {
  const l = stockLevel(s);
  return l === 'out' ? 'Sin stock' : l === 'low' ? 'Stock bajo' : 'Disponible';
};

Object.assign(window, {
  MECA_THEME, MECA_PRODUCTS, UNIT_LABELS, fmtRD, stockLevel, stockColor, stockContainer, stockLabel,
});
