// Pantalla 2: Detalle de producto
const T = window.MECA_THEME;

const DetailScreen = () => {
  const p = window.MECA_PRODUCTS[1]; // Filtro Mann (stock bajo: 4)
  const c = window.stockColor(p.stock);
  const bg = window.stockContainer(p.stock);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: T.surfaceDim, fontFamily: 'Roboto, system-ui, sans-serif' }}>
      <StatusBar dark bg={T.primary} />
      <TopAppBar
        dark
        title="Detalle de producto"
        leading={<IconButton icon="back" color="#fff" />}
        trailing={<div style={{ display: 'flex' }}>
          <IconButton icon="barcode" color="#fff" />
          <IconButton icon="more" color="#fff" />
        </div>}
      />

      <div style={{ flex: 1, overflow: 'auto' }}>
        {/* Hero */}
        <div style={{ background: T.primary, padding: '8px 20px 24px', color: '#fff' }}>
          <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
            <div style={{
              width: 72, height: 72, borderRadius: 16, background: 'rgba(255,255,255,0.15)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name="inventory" size={36} color="#fff" />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 11, opacity: 0.85, fontWeight: 600, letterSpacing: 1 }}>SKU · MN-W67-2</div>
              <div style={{ fontSize: 20, fontWeight: 700, lineHeight: '26px', marginTop: 2 }}>{p.name}</div>
              <div style={{ fontSize: 13, opacity: 0.9, marginTop: 4 }}>{p.description}</div>
            </div>
          </div>

          {/* Pill categoría */}
          <div style={{ marginTop: 14, display: 'flex', gap: 8 }}>
            <div style={{
              padding: '4px 10px', borderRadius: 6, background: 'rgba(255,255,255,0.15)',
              fontSize: 12, fontWeight: 600,
            }}>{p.category}</div>
            <div style={{
              padding: '4px 10px', borderRadius: 6, background: 'rgba(255,255,255,0.15)',
              fontSize: 12, fontWeight: 600,
            }}>{window.UNIT_LABELS[p.unit]}</div>
          </div>
        </div>

        {/* Stock alert card */}
        <div style={{ padding: '16px 16px 0' }}>
          <div style={{
            background: bg, borderRadius: 16, padding: 16,
            display: 'flex', gap: 14, alignItems: 'center',
            border: `1px solid ${c}33`,
          }}>
            <div style={{
              width: 48, height: 48, borderRadius: 24, background: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name="warning" size={24} color={c} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: c }}>Stock bajo</div>
              <div style={{ fontSize: 13, color: T.onSurface, marginTop: 2 }}>
                Solo quedan <b>4 unidades</b>. Considera reordenar pronto.
              </div>
            </div>
          </div>
        </div>

        {/* Info grid */}
        <div style={{ padding: '16px' }}>
          <div style={{
            background: T.surface, borderRadius: 16, padding: 8,
            border: `1px solid ${T.outlineVariant}`,
          }}>
            {/* Stock & precio */}
            <div style={{ display: 'flex' }}>
              <div style={{ flex: 1, padding: 16 }}>
                <div style={{ fontSize: 11, color: T.onSurfaceMuted, fontWeight: 600, letterSpacing: 0.5 }}>STOCK ACTUAL</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 6 }}>
                  <span style={{ fontSize: 32, fontWeight: 700, color: c, lineHeight: 1 }}>{p.stock}</span>
                  <span style={{ fontSize: 14, color: T.onSurfaceMuted, fontWeight: 500 }}>{window.UNIT_LABELS[p.unit].toLowerCase()}s</span>
                </div>
              </div>
              <div style={{ width: 1, background: T.outlineVariant, margin: '12px 0' }} />
              <div style={{ flex: 1, padding: 16 }}>
                <div style={{ fontSize: 11, color: T.onSurfaceMuted, fontWeight: 600, letterSpacing: 0.5 }}>PRECIO UNITARIO</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 6 }}>
                  <span style={{ fontSize: 14, color: T.onSurfaceMuted, fontWeight: 500 }}>RD$</span>
                  <span style={{ fontSize: 28, fontWeight: 700, color: T.onSurface, lineHeight: 1 }}>350.<span style={{ fontSize: 18 }}>00</span></span>
                </div>
              </div>
            </div>
            <div style={{ height: 1, background: T.outlineVariant, margin: '0 8px' }} />
            <div style={{ padding: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: 11, color: T.onSurfaceMuted, fontWeight: 600, letterSpacing: 0.5 }}>VALOR TOTAL EN BODEGA</div>
                <div style={{ fontSize: 18, fontWeight: 700, color: T.primary, marginTop: 4 }}>{window.fmtRD(p.price * p.stock)}</div>
              </div>
              <div style={{
                padding: '8px 12px', borderRadius: 10, background: T.primaryContainer,
                color: T.primary, fontSize: 13, fontWeight: 600,
              }}>4 × {window.fmtRD(p.price)}</div>
            </div>
          </div>
        </div>

        {/* Stock controls */}
        <div style={{ padding: '0 16px 16px' }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: T.onSurface, marginBottom: 10 }}>Ajuste rápido de stock</div>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <button style={{
              width: 56, height: 56, borderRadius: 28, border: `1px solid ${T.outline}`,
              background: T.surface, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="minus" size={24} color={T.primary} />
            </button>
            <div style={{
              flex: 1, height: 56, borderRadius: 16, background: T.surface,
              border: `1px solid ${T.outlineVariant}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 24, fontWeight: 700, color: T.onSurface,
            }}>4</div>
            <button style={{
              width: 56, height: 56, borderRadius: 28, border: 'none',
              background: T.primary, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="add" size={24} color="#fff" />
            </button>
          </div>
        </div>

        {/* Actividad */}
        <div style={{ padding: '0 16px 16px' }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: T.onSurface, marginBottom: 10 }}>Actividad reciente</div>
          <div style={{ background: T.surface, borderRadius: 16, border: `1px solid ${T.outlineVariant}`, overflow: 'hidden' }}>
            {[
              { t: 'Salida — Factura F2026-0142', s: 'Hace 2 horas · Toyota Corolla 2018', n: '-2', c: T.error },
              { t: 'Entrada — Compra a proveedor', s: 'Ayer · OrdCompra #88', n: '+6', c: T.stockOk },
              { t: 'Ajuste de inventario', s: '3 días · Conteo físico', n: '0', c: T.onSurfaceMuted },
            ].map((it, i) => (
              <div key={i} style={{
                padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12,
                borderBottom: i < 2 ? `1px solid ${T.outlineVariant}` : 'none',
              }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: T.onSurface }}>{it.t}</div>
                  <div style={{ fontSize: 12, color: T.onSurfaceMuted, marginTop: 2 }}>{it.s}</div>
                </div>
                <div style={{
                  padding: '4px 10px', borderRadius: 8,
                  background: it.c === T.onSurfaceMuted ? T.surfaceContainer : it.c + '15',
                  color: it.c, fontSize: 13, fontWeight: 700,
                }}>{it.n}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Acciones */}
        <div style={{ padding: '0 16px 24px', display: 'flex', gap: 10 }}>
          <FilledButton icon="edit" full>Editar</FilledButton>
          <button style={{
            height: 48, width: 48, borderRadius: 24, border: `1px solid ${T.outline}`,
            background: 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name="delete" size={20} color={T.error} />
          </button>
        </div>
      </div>

      <NavBar />
    </div>
  );
};

window.DetailScreen = DetailScreen;
