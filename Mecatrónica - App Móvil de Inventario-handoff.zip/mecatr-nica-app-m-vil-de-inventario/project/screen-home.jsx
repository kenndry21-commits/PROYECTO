// Pantalla 1: Lista de productos (Home)
const T = window.MECA_THEME;

const ProductRow = ({ p, onClick }) => {
  const c = window.stockColor(p.stock);
  const bg = window.stockContainer(p.stock);
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px',
      background: T.surface, cursor: 'pointer', position: 'relative',
    }}>
      {/* Stock indicator strip */}
      <div style={{ position: 'absolute', left: 0, top: 8, bottom: 8, width: 3, background: c, borderRadius: '0 2px 2px 0' }} />

      {/* Avatar */}
      <div style={{
        width: 48, height: 48, borderRadius: 12, background: T.surfaceContainer,
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        <Icon name={
          p.category === 'Lubricantes' ? 'pricetag' :
          p.category === 'Filtros' ? 'inventory' :
          p.category === 'Frenos' ? 'warning' :
          p.category === 'Motor' ? 'settings' : 'category'
        } size={22} color={T.primary} />
      </div>

      {/* Info */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 15, fontWeight: 600, color: T.onSurface, lineHeight: '20px',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          fontFamily: 'Roboto, system-ui, sans-serif',
        }}>{p.name}</div>
        <div style={{
          fontSize: 13, color: T.onSurfaceMuted, lineHeight: '18px', marginTop: 2,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          fontFamily: 'Roboto, system-ui, sans-serif',
        }}>{p.description}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 6 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: T.primary, fontFamily: 'Roboto, system-ui, sans-serif' }}>
            {window.fmtRD(p.price)}
          </span>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 5,
            padding: '2px 8px', borderRadius: 6, background: bg,
          }}>
            <div style={{ width: 5, height: 5, borderRadius: 3, background: c }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: c, fontFamily: 'Roboto, system-ui, sans-serif' }}>
              {p.stock} {window.UNIT_LABELS[p.unit]?.toLowerCase()}{p.stock !== 1 ? 's' : ''}
            </span>
          </div>
        </div>
      </div>

      <Icon name="arrowRight" size={20} color={T.onSurfaceMuted} />
    </div>
  );
};

const SummaryCard = () => {
  const total = window.MECA_PRODUCTS.length;
  const low = window.MECA_PRODUCTS.filter(p => p.stock > 0 && p.stock <= 5).length;
  const out = window.MECA_PRODUCTS.filter(p => p.stock <= 0).length;
  const value = window.MECA_PRODUCTS.reduce((s, p) => s + p.price * p.stock, 0);
  return (
    <div style={{ padding: '12px 16px 4px' }}>
      <div style={{
        background: T.primary, borderRadius: 16, padding: 16,
        color: '#fff', position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', right: -30, top: -30, width: 140, height: 140, borderRadius: 70, background: 'rgba(255,255,255,0.06)' }} />
        <div style={{ fontSize: 12, fontWeight: 500, opacity: 0.85, fontFamily: 'Roboto, system-ui, sans-serif', letterSpacing: 0.5 }}>VALOR DE INVENTARIO</div>
        <div style={{ fontSize: 28, fontWeight: 700, marginTop: 4, fontFamily: 'Roboto, system-ui, sans-serif' }}>{window.fmtRD(value)}</div>
        <div style={{ display: 'flex', gap: 16, marginTop: 14, position: 'relative' }}>
          <div>
            <div style={{ fontSize: 11, opacity: 0.8 }}>PRODUCTOS</div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>{total}</div>
          </div>
          <div style={{ width: 1, background: 'rgba(255,255,255,0.2)' }} />
          <div>
            <div style={{ fontSize: 11, opacity: 0.8 }}>STOCK BAJO</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#FCD34D' }}>{low}</div>
          </div>
          <div style={{ width: 1, background: 'rgba(255,255,255,0.2)' }} />
          <div>
            <div style={{ fontSize: 11, opacity: 0.8 }}>SIN STOCK</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#FCA5A5' }}>{out}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

const FilterChips = ({ active = 'todos' }) => {
  const chips = [
    { id: 'todos', label: 'Todos', count: 10 },
    { id: 'disponible', label: 'Disponible', count: 6, color: T.stockOkContainer, fg: T.stockOk },
    { id: 'bajo', label: 'Stock bajo', count: 2, color: T.stockLowContainer, fg: T.stockLow },
    { id: 'agotado', label: 'Sin stock', count: 2, color: T.stockOutContainer, fg: T.stockOut },
  ];
  return (
    <div style={{ display: 'flex', gap: 8, padding: '8px 16px 12px', overflowX: 'auto' }}>
      {chips.map(c => (
        <div key={c.id} style={{
          height: 34, padding: '0 14px', borderRadius: 10,
          border: active === c.id ? 'none' : `1px solid ${T.outline}`,
          background: active === c.id ? (c.color || T.primaryContainer) : 'transparent',
          color: active === c.id ? (c.fg || T.primary) : T.onSurfaceVariant,
          fontSize: 13, fontWeight: 600,
          display: 'inline-flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap', flexShrink: 0,
          fontFamily: 'Roboto, system-ui, sans-serif',
        }}>
          {active === c.id && <Icon name="check" size={14} color={c.fg || T.primary} />}
          {c.label}
          <span style={{ opacity: 0.7, fontWeight: 500 }}>· {c.count}</span>
        </div>
      ))}
    </div>
  );
};

const HomeScreen = () => (
  <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: T.surfaceDim, fontFamily: 'Roboto, system-ui, sans-serif' }}>
    <StatusBar />
    <TopAppBar
      title="Inventario"
      subtitle="Mecatrónica · Taller Automotriz"
      leading={<div style={{
        width: 40, height: 40, borderRadius: 12, background: T.primary,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name="truck" size={22} color="#fff" />
      </div>}
      trailing={<div style={{ display: 'flex' }}>
        <IconButton icon="search" color={T.onSurface} />
        <IconButton icon="more" color={T.onSurface} />
      </div>}
    />

    <div style={{ flex: 1, overflow: 'auto', position: 'relative' }}>
      <SummaryCard />
      <FilterChips active="todos" />

      {/* Productos */}
      <div style={{ padding: '0 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: T.onSurfaceMuted, letterSpacing: 0.5 }}>10 PRODUCTOS</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: T.primary, fontWeight: 600 }}>
          <Icon name="sort" size={16} color={T.primary} /> Stock ↓
        </div>
      </div>

      <div style={{ background: T.surface, marginBottom: 100 }}>
        {window.MECA_PRODUCTS.slice(0, 7).map((p, i) => (
          <React.Fragment key={p.id}>
            <ProductRow p={p} />
            {i < 6 && <div style={{ height: 1, background: T.outlineVariant, marginLeft: 78 }} />}
          </React.Fragment>
        ))}
      </div>

      {/* FAB */}
      <div style={{ position: 'absolute', right: 16, bottom: 16 }}>
        <ExtendedFAB icon="add">Nuevo producto</ExtendedFAB>
      </div>
    </div>

    <BottomNav active="home" />
    <NavBar />
  </div>
);

window.HomeScreen = HomeScreen;
window.ProductRow = ProductRow;
