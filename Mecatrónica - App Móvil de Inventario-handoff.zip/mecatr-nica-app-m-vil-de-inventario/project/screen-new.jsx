// Pantalla 3: Formulario nuevo producto
const T = window.MECA_THEME;

const NewProductScreen = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: T.surface, fontFamily: 'Roboto, system-ui, sans-serif' }}>
      <StatusBar />
      <TopAppBar
        title="Nuevo producto"
        leading={<IconButton icon="close" color={T.onSurface} />}
        trailing={<button style={{
          height: 36, padding: '0 16px', borderRadius: 18, border: 'none',
          background: T.primary, color: '#fff', fontSize: 13, fontWeight: 600,
          marginRight: 8, fontFamily: 'inherit',
        }}>Guardar</button>}
      />

      <div style={{ flex: 1, overflow: 'auto', padding: '8px 16px 100px' }}>
        {/* Hero icon */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 0 24px' }}>
          <div style={{
            width: 88, height: 88, borderRadius: 24, background: T.primaryContainer,
            display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative',
          }}>
            <Icon name="image" size={36} color={T.primary} />
            <div style={{
              position: 'absolute', right: -6, bottom: -6, width: 36, height: 36, borderRadius: 18,
              background: T.primary, display: 'flex', alignItems: 'center', justifyContent: 'center',
              border: '3px solid #fff',
            }}>
              <Icon name="camera" size={18} color="#fff" />
            </div>
          </div>
          <div style={{ fontSize: 13, color: T.onSurfaceMuted, marginTop: 10, fontWeight: 500 }}>Agregar foto del producto</div>
        </div>

        {/* Section: Información básica */}
        <SectionLabel>INFORMACIÓN DEL PRODUCTO</SectionLabel>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 24 }}>
          <TextField label="Nombre del producto" value="Aceite Mobil 1 5W-30" focused />
          <TextField label="Descripción" value="Aceite sintético full para motor a gasolina, 1 galón" multiline />

          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{ flex: 1 }}>
              <TextField
                label="Precio"
                value="1,850.00"
                leading={<span style={{ fontSize: 16, fontWeight: 600, color: T.onSurfaceMuted }}>RD$</span>}
              />
            </div>
          </div>
        </div>

        {/* Stock & unidad */}
        <SectionLabel>STOCK Y UNIDAD DE MEDIDA</SectionLabel>

        <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
          <div style={{ flex: 1 }}>
            <TextField label="Stock inicial" value="12" />
          </div>
          <div style={{ flex: 1.2 }}>
            <TextField
              label="Unidad"
              value="Galón"
              trailing={<Icon name="arrowDown" size={18} color={T.onSurfaceMuted} />}
            />
          </div>
        </div>

        {/* Unit chips */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 12, color: T.onSurfaceMuted, fontWeight: 600, marginBottom: 8 }}>SELECCIÓN RÁPIDA</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {[
              { id: 'unidad', label: 'Unidad' },
              { id: 'galon', label: 'Galón', selected: true },
              { id: 'litro', label: 'Litro' },
              { id: 'kg', label: 'Kilogramo' },
              { id: 'caja', label: 'Caja' },
            ].map(u => (
              <Chip key={u.id} selected={u.selected}>{u.label}</Chip>
            ))}
          </div>
        </div>

        {/* Threshold */}
        <div style={{ marginTop: 24 }}>
          <SectionLabel>ALERTA DE STOCK BAJO</SectionLabel>
          <div style={{
            background: T.surfaceContainer, borderRadius: 16, padding: 16,
            display: 'flex', alignItems: 'center', gap: 14,
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: T.onSurface }}>Avisar cuando stock ≤</div>
              <div style={{ fontSize: 12, color: T.onSurfaceMuted, marginTop: 2 }}>Recibirás notificación cuando se agote</div>
            </div>
            <div style={{
              minWidth: 64, height: 36, padding: '0 12px', borderRadius: 18,
              background: T.surface, border: `1px solid ${T.outline}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 16, fontWeight: 700, color: T.onSurface,
            }}>5</div>
          </div>
        </div>
      </div>

      <NavBar />
    </div>
  );
};

const SectionLabel = ({ children }) => (
  <div style={{
    fontSize: 12, fontWeight: 700, color: T.primary, letterSpacing: 0.8,
    margin: '0 0 12px', fontFamily: 'Roboto, system-ui, sans-serif',
  }}>{children}</div>
);

window.NewProductScreen = NewProductScreen;
window.SectionLabel = SectionLabel;
