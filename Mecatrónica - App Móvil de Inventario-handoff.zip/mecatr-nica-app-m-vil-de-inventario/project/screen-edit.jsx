// Pantalla 4: Editar producto
const T = window.MECA_THEME;

const EditProductScreen = () => {
  const p = window.MECA_PRODUCTS[1];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: T.surface, fontFamily: 'Roboto, system-ui, sans-serif' }}>
      <StatusBar />
      <TopAppBar
        title="Editar producto"
        subtitle="SKU · MN-W67-2"
        leading={<IconButton icon="back" color={T.onSurface} />}
        trailing={<div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <IconButton icon="delete" color={T.error} />
          <button style={{
            height: 36, padding: '0 16px', borderRadius: 18, border: 'none',
            background: T.primary, color: '#fff', fontSize: 13, fontWeight: 600,
            marginRight: 8, fontFamily: 'inherit',
          }}>Actualizar</button>
        </div>}
      />

      <div style={{ flex: 1, overflow: 'auto', padding: '16px 16px 100px' }}>
        {/* Status banner */}
        <div style={{
          background: T.stockLowContainer, borderRadius: 12, padding: '12px 14px',
          display: 'flex', gap: 10, alignItems: 'center', marginBottom: 20,
        }}>
          <Icon name="warning" size={20} color={T.stockLow} />
          <div style={{ flex: 1, fontSize: 13, color: T.onSurface }}>
            <b>Stock bajo:</b> 4 unidades · Última actualización hace 2h
          </div>
        </div>

        <SectionLabel>INFORMACIÓN DEL PRODUCTO</SectionLabel>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 24 }}>
          <TextField label="Nombre del producto" value={p.name} />
          <TextField label="Descripción" value={p.description} multiline />

          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{ flex: 1 }}>
              <TextField
                label="Precio"
                value="350.00"
                leading={<span style={{ fontSize: 16, fontWeight: 600, color: T.onSurfaceMuted }}>RD$</span>}
              />
            </div>
            <div style={{ flex: 1 }}>
              <TextField
                label="Categoría"
                value="Filtros"
                trailing={<Icon name="arrowDown" size={18} color={T.onSurfaceMuted} />}
              />
            </div>
          </div>
        </div>

        <SectionLabel>STOCK Y UNIDAD DE MEDIDA</SectionLabel>

        <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
          <div style={{ flex: 1 }}>
            <TextField
              label="Stock actual"
              value="4"
              focused
              supporting="Modificado hace 2 horas"
            />
          </div>
          <div style={{ flex: 1.2 }}>
            <TextField
              label="Unidad"
              value="Unidad"
              trailing={<Icon name="arrowDown" size={18} color={T.onSurfaceMuted} />}
            />
          </div>
        </div>

        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 12, color: T.onSurfaceMuted, fontWeight: 600, marginBottom: 8 }}>SELECCIÓN RÁPIDA</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {[
              { id: 'unidad', label: 'Unidad', selected: true },
              { id: 'galon', label: 'Galón' },
              { id: 'litro', label: 'Litro' },
              { id: 'kg', label: 'Kilogramo' },
              { id: 'caja', label: 'Caja' },
            ].map(u => (
              <Chip key={u.id} selected={u.selected}>{u.label}</Chip>
            ))}
          </div>
        </div>

        <SectionLabel>HISTORIAL DE PRECIO</SectionLabel>
        <div style={{
          background: T.surfaceContainer, borderRadius: 16, padding: 16,
          display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16,
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, color: T.onSurfaceMuted }}>Precio anterior</div>
            <div style={{ fontSize: 16, fontWeight: 600, color: T.onSurface, textDecoration: 'line-through' }}>RD$320.00</div>
          </div>
          <Icon name="arrowRight" size={20} color={T.onSurfaceMuted} />
          <div style={{ flex: 1, textAlign: 'right' }}>
            <div style={{ fontSize: 13, color: T.stockOk, fontWeight: 600 }}>Nuevo +9.4%</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: T.primary }}>RD$350.00</div>
          </div>
        </div>

        {/* Danger zone */}
        <div style={{
          marginTop: 24, border: `1px solid ${T.errorContainer}`, borderRadius: 16, padding: 16,
          background: '#FEF2F2',
        }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: T.error, marginBottom: 4 }}>Zona de peligro</div>
          <div style={{ fontSize: 13, color: T.onSurfaceMuted, marginBottom: 12 }}>
            Eliminar este producto borrará su historial y no podrá revertirse.
          </div>
          <button style={{
            height: 40, padding: '0 16px', borderRadius: 20,
            border: `1px solid ${T.error}`, background: 'transparent', color: T.error,
            fontSize: 13, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 8,
            fontFamily: 'inherit',
          }}>
            <Icon name="delete" size={16} color={T.error} />
            Eliminar producto
          </button>
        </div>
      </div>

      <NavBar />
    </div>
  );
};

window.EditProductScreen = EditProductScreen;
