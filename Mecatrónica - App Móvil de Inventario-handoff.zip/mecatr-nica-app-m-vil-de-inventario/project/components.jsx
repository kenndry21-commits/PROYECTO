// Componentes Material 3 reutilizables para Mecatrónica

const T = window.MECA_THEME;

// Status bar Android (limpio, modo claro)
const StatusBar = ({ dark = false, bg }) => {
  const c = dark ? '#fff' : T.onSurface;
  return (
    <div style={{
      height: 32, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 20px', background: bg || 'transparent',
      fontFamily: 'Roboto, system-ui, sans-serif', fontSize: 14, fontWeight: 600, color: c,
      flexShrink: 0,
    }}>
      <span>9:41</span>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="16" height="11" viewBox="0 0 16 11" fill={c}><path d="M8 0a8 8 0 0 1 5.66 2.34l-1.41 1.42A6 6 0 0 0 8 2a6 6 0 0 0-4.24 1.76L2.34 2.34A8 8 0 0 1 8 0zm0 4a4 4 0 0 1 2.83 1.17l-1.42 1.42A2 2 0 0 0 8 6a2 2 0 0 0-1.41.59L5.17 5.17A4 4 0 0 1 8 4zm0 4a1 1 0 1 1-1 1 1 1 0 0 1 1-1z"/></svg>
        <svg width="16" height="11" viewBox="0 0 16 11" fill={c}><path d="M2 11h2V7H2zm4 0h2V4H6zm4 0h2V1h-2zm4 0h2V0h-2z"/></svg>
        <svg width="22" height="11" viewBox="0 0 22 11" fill="none" stroke={c} strokeWidth="1"><rect x="0.5" y="0.5" width="19" height="10" rx="2"/><rect x="2" y="2" width="14" height="7" rx="1" fill={c}/><rect x="20" y="3.5" width="1.5" height="4" rx="0.5" fill={c}/></svg>
      </div>
    </div>
  );
};

// Gesture nav bar
const NavBar = ({ dark = false, bg }) => (
  <div style={{
    height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: bg || 'transparent', flexShrink: 0,
  }}>
    <div style={{ width: 120, height: 4, borderRadius: 2, background: dark ? '#fff' : '#0F172A', opacity: 0.45 }} />
  </div>
);

// Top App Bar
const TopAppBar = ({ title, leading, trailing, dark, subtitle }) => (
  <div style={{
    height: subtitle ? 72 : 64, display: 'flex', alignItems: 'center', gap: 4,
    padding: '0 4px 0 4px', background: dark ? T.primary : T.surface,
    color: dark ? '#fff' : T.onSurface,
    fontFamily: 'Roboto, system-ui, sans-serif', flexShrink: 0,
    borderBottom: dark ? 'none' : `1px solid ${T.outlineVariant}`,
  }}>
    <div style={{ width: 48, height: 48, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 24 }}>
      {leading}
    </div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 22, fontWeight: 500, lineHeight: '28px', letterSpacing: 0 }}>{title}</div>
      {subtitle && <div style={{ fontSize: 13, opacity: 0.85, lineHeight: '16px', marginTop: 2 }}>{subtitle}</div>}
    </div>
    <div style={{ display: 'flex', alignItems: 'center', paddingRight: 4 }}>
      {trailing}
    </div>
  </div>
);

const IconButton = ({ icon, color, onClick, size = 24, bg }) => (
  <button onClick={onClick} style={{
    width: 44, height: 44, borderRadius: 22, border: 'none', background: bg || 'transparent',
    display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', padding: 0,
  }}>
    <Icon name={icon} color={color || 'currentColor'} size={size} />
  </button>
);

// Botón filled M3
const FilledButton = ({ children, icon, onClick, full, color }) => (
  <button onClick={onClick} style={{
    height: 48, padding: '0 24px', borderRadius: 24, border: 'none',
    background: color || T.primary, color: '#fff',
    fontSize: 15, fontWeight: 600, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    fontFamily: 'Roboto, system-ui, sans-serif',
    width: full ? '100%' : 'auto', flexShrink: 0,
    boxShadow: '0 1px 2px rgba(0,0,0,0.08)',
  }}>
    {icon && <Icon name={icon} size={18} color="#fff" />}
    {children}
  </button>
);

// Botón outline
const OutlineButton = ({ children, icon, onClick, full }) => (
  <button onClick={onClick} style={{
    height: 48, padding: '0 24px', borderRadius: 24,
    border: `1px solid ${T.outline}`, background: 'transparent', color: T.primary,
    fontSize: 15, fontWeight: 600, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    fontFamily: 'Roboto, system-ui, sans-serif',
    width: full ? '100%' : 'auto', flexShrink: 0,
  }}>
    {icon && <Icon name={icon} size={18} />}
    {children}
  </button>
);

// Floating Action Button extendido
const ExtendedFAB = ({ children, icon, onClick }) => (
  <button onClick={onClick} style={{
    height: 56, padding: '0 20px 0 16px', borderRadius: 16, border: 'none',
    background: T.primary, color: '#fff',
    fontSize: 15, fontWeight: 600, cursor: 'pointer',
    display: 'flex', alignItems: 'center', gap: 12,
    fontFamily: 'Roboto, system-ui, sans-serif',
    boxShadow: '0 4px 12px rgba(30,58,138,0.35)',
  }}>
    <Icon name={icon} size={22} color="#fff" />
    {children}
  </button>
);

// Chip M3
const Chip = ({ children, selected, color, leading }) => (
  <div style={{
    height: 32, padding: leading ? '0 12px 0 8px' : '0 12px',
    borderRadius: 8,
    border: selected ? 'none' : `1px solid ${T.outline}`,
    background: selected ? (color || T.primaryContainer) : 'transparent',
    color: selected ? T.onPrimaryContainer : T.onSurfaceVariant,
    fontSize: 13, fontWeight: 500,
    display: 'inline-flex', alignItems: 'center', gap: 6,
    fontFamily: 'Roboto, system-ui, sans-serif', whiteSpace: 'nowrap', flexShrink: 0,
  }}>
    {leading}
    {children}
  </div>
);

// Stock badge
const StockBadge = ({ stock, unit, mini }) => {
  const c = window.stockColor(stock);
  const bg = window.stockContainer(stock);
  const lbl = window.stockLabel(stock);
  if (mini) {
    return (
      <div style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '4px 10px', borderRadius: 8, background: bg, color: c,
        fontSize: 12, fontWeight: 600,
      }}>
        <div style={{ width: 6, height: 6, borderRadius: 3, background: c }} />
        {stock} {unit}
      </div>
    );
  }
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '6px 12px', borderRadius: 10, background: bg, color: c,
      fontSize: 13, fontWeight: 600,
    }}>
      <Icon name={stock <= 0 ? 'error' : stock <= 5 ? 'warning' : 'check'} size={14} color={c} />
      {lbl}
    </div>
  );
};

// Text field M3 outlined
const TextField = ({ label, value, placeholder, supporting, error, leading, trailing, focused, multiline }) => {
  const hasValue = value && value.length > 0;
  const isFloating = focused || hasValue;
  const borderColor = error ? T.error : focused ? T.primary : T.outline;
  const labelColor = error ? T.error : focused ? T.primary : T.onSurfaceMuted;
  return (
    <div>
      <div style={{
        position: 'relative', minHeight: multiline ? 96 : 56,
        border: `${focused ? 2 : 1}px solid ${borderColor}`,
        borderRadius: 8, padding: '8px 16px',
        display: 'flex', alignItems: 'center', gap: 12,
        background: T.surface,
      }}>
        {leading && <div style={{ color: T.onSurfaceMuted }}>{leading}</div>}
        <div style={{ flex: 1, position: 'relative', alignSelf: multiline ? 'flex-start' : 'center', paddingTop: multiline ? 12 : 0 }}>
          <span style={{
            position: 'absolute',
            top: isFloating ? -16 : (multiline ? 0 : '50%'),
            transform: isFloating ? 'none' : (multiline ? 'none' : 'translateY(-50%)'),
            left: 0, fontSize: isFloating ? 12 : 16,
            color: labelColor, background: T.surface, padding: isFloating ? '0 4px' : 0,
            transition: 'all .15s', fontFamily: 'Roboto, system-ui, sans-serif',
            pointerEvents: 'none',
          }}>{label}</span>
          {hasValue ? (
            <div style={{
              fontSize: 16, color: T.onSurface, fontFamily: 'Roboto, system-ui, sans-serif',
              minHeight: 24, paddingTop: isFloating && !multiline ? 8 : 0,
              whiteSpace: multiline ? 'pre-wrap' : 'nowrap',
            }}>{value}</div>
          ) : (
            placeholder && isFloating && <div style={{ fontSize: 16, color: T.onSurfaceMuted, paddingTop: 8 }}>{placeholder}</div>
          )}
          {focused && (
            <div style={{
              position: 'absolute', width: 2, height: 20, background: T.primary,
              top: isFloating ? 12 : '50%', transform: isFloating ? 'none' : 'translateY(-50%)',
              left: hasValue ? `${(value||'').length * 9}px` : 0,
              animation: 'blink 1s infinite',
            }} />
          )}
        </div>
        {trailing && <div style={{ color: T.onSurfaceMuted }}>{trailing}</div>}
      </div>
      {supporting && (
        <div style={{
          fontSize: 12, color: error ? T.error : T.onSurfaceMuted,
          padding: '4px 16px 0', fontFamily: 'Roboto, system-ui, sans-serif',
        }}>{supporting}</div>
      )}
    </div>
  );
};

// Bottom navigation Material 3
const BottomNav = ({ active = 'home' }) => {
  const items = [
    { id: 'home', icon: 'inventory', label: 'Inventario' },
    { id: 'history', icon: 'history', label: 'Movimientos' },
    { id: 'chart', icon: 'chart', label: 'Reportes' },
    { id: 'settings', icon: 'settings', label: 'Ajustes' },
  ];
  return (
    <div style={{
      height: 80, background: T.surfaceContainer, display: 'flex',
      borderTop: `1px solid ${T.outlineVariant}`, flexShrink: 0,
      paddingTop: 12, paddingBottom: 16,
    }}>
      {items.map(it => (
        <div key={it.id} style={{
          flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
        }}>
          <div style={{
            height: 32, width: 64, borderRadius: 16,
            background: active === it.id ? T.primaryContainer : 'transparent',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name={it.icon} size={22} color={active === it.id ? T.primary : T.onSurfaceVariant} />
          </div>
          <div style={{
            fontSize: 12, fontWeight: active === it.id ? 600 : 500,
            color: active === it.id ? T.primary : T.onSurfaceVariant,
            fontFamily: 'Roboto, system-ui, sans-serif',
          }}>{it.label}</div>
        </div>
      ))}
    </div>
  );
};

Object.assign(window, {
  StatusBar, NavBar, TopAppBar, IconButton, FilledButton, OutlineButton,
  ExtendedFAB, Chip, StockBadge, TextField, BottomNav,
});
